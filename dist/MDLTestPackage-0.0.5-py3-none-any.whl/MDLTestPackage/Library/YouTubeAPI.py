from googleapiclient.discovery import build
import googleapiclient.errors
from MDLTestPackage.Library import keyDir
from configparser import ConfigParser
from distutils.util import strtobool


def login():
    keys = ConfigParser()
    keys.read(keyDir)
    key = keys['USER']['youtubeAPI'] if keys['USER']['youtubeAPI'] else input('API key: ')
    response = build('youtube', 'v3', developerKey=key)
    if response and key != keys['USER']['youtubeAPI']:
        answer = strtobool(input('Save API in key configuration?'))
        if answer:
            keys['USER']['youtubeAPI'] = key
            with open(keyDir, 'w') as r:
                keys.write(r)
            print('Saved key')
        else:
            print('Key not saved')
    return response


def getPlayList(youtube, playlistId, pageToken=None, maxResults=50, **kwargs):
    playlist = []
    while True:
        page = youtube.playlistems().list(
            part='snippet',
            playlistId=playlistId,
            pageToken=pageToken,
            maxResults=maxResults,
            **kwargs
        )
        playlist.append(page['items'])
        if page['nextPageToken']:
            pageToken = page['nextPageToken']
        else:
            break
    return playlist


def getVideoInfo(youtube, videoId):
    return youtube.videos().list(
        part='snippet',
        id=videoId
    )


def getThumbnails(youtube, videoId=None, playListId=None, quality='maxres'):
    if videoId:
        playlist = getVideoInfo(youtube, videoId=videoId)
    elif playListId:
        playlist = getPlayList(youtube, playListId)
    else:
        return None
    return [{
        'title': i['snippet']['title'],
        'thumbnail': i['snippet']['thumbnail'][quality]['url'],
        'url': f"https://www.youtube.com/watch?v={i['snippet']['resourceId']['videoId']}"
    } for i in playlist]

